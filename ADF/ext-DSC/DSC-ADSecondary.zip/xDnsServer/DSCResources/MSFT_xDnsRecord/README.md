# Description

The xDnsRecord DSC resource manages IPv4 host (A), CName, or PTR DNS records against a specific zone on a Domian Name System (DNS) server.
